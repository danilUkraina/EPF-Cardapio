<link rel="stylesheet" type="text/css" href="/lib/css/anim.css?v7"/>
<link rel="stylesheet" type="text/css" href="/lib/css/dark.css?v7"/>
<link rel="stylesheet" type="text/css" href="/lib/css/main.css?v8"/>
<link rel="stylesheet" type="text/css" href="/lib/css/debug.css?v53"/>
<link rel="stylesheet" type="text/css" href="/lib/css/scale.css?v7"/>
