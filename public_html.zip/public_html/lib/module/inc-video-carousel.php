<div class="container fill">
	<div id="myCarousel" class="carousel slide">
		<div class="carousel-inner">
			<!-- Carousel Slide -->
			<div class="item active">
				<div class="fill">
					<div class="video-con-container">
						<div class='video-con-left'>
							<div class='video-con-wrapper'>
								
								
								<div class='video-img-thumbnail' style="background: url('/img/videos/1.jpeg') no-repeat center; background-size: cover;">
								</div>
							</div>
						</div>
						<div class='video-con-right'>
							<div class="video-tx1-description darkmode-txt scale-content-txt-4">
								<div class='video-emp-block'>
								</div>
								<h2>Sobre nós</h2>
								<h3>A Escola Profissional do Fundão foi criada em 1992, por Contrato Programa celebrado a 29 de Julho, entre a Câmara Municipal e a Associação Comercial e Industrial do Fundão, com o Ministério da Educação</h3>
								<a href="https://www.epfundao.edu.pt/page/sobre-nos">Aprender mais...</a>
							</div>
						</div>
					</div>
				</div>
			</div>
	</div>
</div>