<!doctype html>
<html lang="en-US">

<head>
	<title>EPF | Menu</title>
	<meta charset="utf-8">
	<meta name="description" content="RPCS3 is a multi-platform open-source Sony PlayStation 3 emulator and debugger written in C++ for Windows, Linux, macOS and FreeBSD. The purpose of this project is to accurately emulate the PlayStation 3 in its entirety with the power of reverse engineering and community collaboration.">
	<meta name="keywords" content="rpcs3, playstation, playstation 3, ps3, emulator, debugger, windows, linux, macos, freebsd, open source, nekotekina, kd11, download">
	<?php include 'lib/module/sys-meta.php'; ?>
	<meta property="og:title" content="RPCS3 - The PlayStation 3 Emulator" />
	<meta property="og:description" content="RPCS3 is a multi-platform open-source Sony PlayStation 3 emulator and debugger written in C++ for Windows, Linux, macOS and FreeBSD made possible with the power of reverse engineering." />
	<meta property="og:image" content="https://rpcs3.net/img/meta/mobile/1200.png" />
	<meta property="og:image:width" content="1200" />
	<meta property="og:image:height" content="630" />
	<meta property="og:url" content="https://rpcs3.net" />
	<meta property="og:locale" content="en_US" />
	<meta property="og:type" content="website" />
	<meta property="og:site_name" content="RPCS3" />

	<meta name="twitter:title" content="RPCS3 - The PlayStation 3 Emulator">
	<meta name="twitter:description" content="RPCS3 is a multi-platform open-source Sony PlayStation 3 emulator and debugger written in C++ for Windows, Linux, macOS and FreeBSD made possible with the power of reverse engineering.">
	<meta name="twitter:image" content="https://rpcs3.net/img/meta/mobile/1200.png">
	<meta name="twitter:site" content="@rpcs3">
	<meta name="twitter:creator" content="@rpcs3">
	<meta name="twitter:card" content="summary_large_image">
	<?php include 'lib/module/sys-css.php'; ?>
	<?php include 'lib/module/sys-js.php'; ?>
</head>

<body>
	<?php include 'lib/module/sys-php.php'; ?>
	<?php
	if (@include_once("lib/compat/objects/Build.php"))
		$build = Build::get_latest();
	?>
	<div class="page-con-content">
		<div class="banner-con-container darkmode-header">
			<div id="object-particles">
			</div>
			<div class="wavebar-con-container">
				<div class="wavebar-con-wrap">
					<div class="wavebar-svg-object">
					</div>
					<div class="wavebar-svg-object">
					</div>
				</div>
			</div>
			<div class='banner-con-title fade-up-onstart'>
				<div class='banner-tx1-title fade-up-onstart pulsate'>
					<h1>Menu</h1>
				</div>
				<div class='banner-con-divider'>
				</div>
				<div class='banner-tx2-title fade-up-onstart'>
				</div>
			</div>
		</div>
		<div class="page-con-container">
			<div class="page-in-container">
				<div class="landing-con-panel" style="background: url('/img/graphics/panels/download.jpg') no-repeat center;">
					<div class='landing-ovr-panel'>
						<div class='landing-tx1-panel'>
						</div>
					</div>
				</div>
				<div class='downloadable-con-container'>


					<div class='segf'>
						<div class='downloadable-con-inner-a'>
							<div class='downloadable-con-graphic' style="background: url(/img/graphics/download/1.png) center top no-repeat; right: -30px; bottom: -38px;">
							</div>
							<div class='downloadable-con-image darkmode-invert' style="background: url(/img/icons/buttons/star.png) center left / 42px no-repeat;">
							</div>
							<div class='downloadable-tx1-title darkmode-txt'>
								<span>Segunda-Feira</span>
							</div>
							<?php
							if (isset($build))
								printf("<a href=\"%s\" download>", $build->get_url_windows());
							?>
							<div class='package-ico-button' style="background: url(/img/icons/buttons/arrow-right.png) center / 22px no-repeat;">
								</div>
								<div class='package-tx1-button'>
									<button class='menu-go'><a href="/ementa/index.html">Menu</a></button>
								</div>
							</div>
						</div>
					</div>

					<div class='terf'>
						<div class='downloadable-con-inner-a'>
							<div class='downloadable-con-graphic' style="background: url(/img/graphics/download/2.png) center top no-repeat; right: -52px; bottom: -38px;">
							</div>
							<div class='downloadable-con-image darkmode-invert' style="background: url(/img/icons/buttons/star.png) center left / 42px no-repeat;">
							</div>
							<div class='downloadable-tx1-title darkmode-txt'>
								<span>Terça-Feira</span>
								</div>
							<?php
							if (isset($build))
								printf("<a href=\"%s\" download>", $build->get_url_windows());
							?>
							<div class='package-ico-button' style="background: url(/img/icons/buttons/arrow-right.png) center / 22px no-repeat;">
								</div>
								<div class='package-tx1-button'>
									<button class='menu-go'><a href="/ementa/index2.html">Menu</a></button>
								</div>
							</div>
					</div>

					<div class='quaf'>
						<div class='downloadable-con-inner-a'>
							<div class='downloadable-con-graphic' style="background: url(/img/graphics/download/3.png) center top no-repeat; right: -52px; bottom: -38px;">
							</div>
							<div class='downloadable-con-image darkmode-invert' style="background: url(/img/icons/buttons/star.png) center left / 42px no-repeat;">
							</div>
							<div class='downloadable-tx1-title darkmode-txt'>
								<span>Quarta-Feira</span>
								</div>
							<?php
							if (isset($build))
								printf("<a href=\"%s\" download>", $build->get_url_windows());
							?>
							<div class='package-ico-button' style="background: url(/img/icons/buttons/arrow-right.png) center / 22px no-repeat;">
								</div>
								<div class='package-tx1-button'>
									<button class='menu-go'><a href="/ementa/index3.html">Menu</a></button>
								</div>
							</div>
					</div>

					<div class='quif'>
						<div class='downloadable-con-inner-a'>
							<div class="downloadable-con-graphic" style="background: url(/img/graphics/download/4.png) center top no-repeat;right: -30px;bottom: -128px;width: 246px;height: 275px;">
							</div>
							<div class='downloadable-con-image darkmode-invert' style="background: url(/img/icons/buttons/star.png) center left / 42px no-repeat;">
							</div>
							<div class='downloadable-tx1-title darkmode-txt'>
								<span>Quinta-Feira</span>
								</div>
							<?php
							if (isset($build))
								printf("<a href=\"%s\" download>", $build->get_url_windows());
							?>
							<div class='package-ico-button' style="background: url(/img/icons/buttons/arrow-right.png) center / 22px no-repeat;">
								</div>
								<div class='package-tx1-button'>
									<button class='menu-go'><a href="/ementa/index4.html">Menu</a></button>
								</div>
							</div>
					</div>

					<div class='sexf'>
						<div class='downloadable-con-inner-a'>
							<div class="downloadable-con-graphic" style="background: url(/img/graphics/download/5.png) center top no-repeat;right: -74px;bottom: -128px;width: 246px;height: 272px;">
							</div>
							<div class='downloadable-con-image darkmode-invert' style="background: url(/img/icons/buttons/star.png) center left / 42px no-repeat;">
							</div>
							<div class='downloadable-tx1-title darkmode-txt'>
								<span>Sexta-Feira</span>
								</div>
							<?php
							if (isset($build))
								printf("<a href=\"%s\" download>", $build->get_url_windows());
							?>
							<div class='package-ico-button' style="background: url(/img/icons/buttons/arrow-right.png) center / 22px no-repeat;">
								</div>
								<div class='package-tx1-button'>
									<button class='menu-go'><a href="/ementa/index5.html">Menu</a></button>
								</div>
							</div>
					</div>

				</div>

			</div>
		</div>

	</div>

	<div class='post-menu'>
		<div class='post-text'>
			<span><br>
			Alimentação saudável</span>
		</div>
			<div class='text-ali'>
				
			<ul>
			<p><br>
				<br>
				Alimento que assegura o crescimento, o desenvolvimento normal<br>
					e a atividade vital de uma pessoa, contribuindo para o fortalecimento<br>
					de sua saúde e a prevenção de doenças. Uma dieta rica em frutas, vegetais,<br>
					grãos integrais, legumes, nozes e peixes está associada a uma boa saúde geral<br>
					e a um risco reduzido de doenças crônicas.<br>
					com baixa ingestão de gordura saturada, gordura trans<br>
					e açúcar e ingestão limitada de sal. Uma dieta saudável envolve<br>
					um baixo nível de consumo de produtos de grãos refinados, carnes<br>
					processadas. (por exemplo, salsichas) e produtos açucarados.<br>
					As recomendações para uma alimentação saudável entre países para produtos<br>
					individuais podem diferir, provavelmente com base nas culturas nacionais<br>
					e nos hábitos alimentares.</p></ul>
			</div>
			<img src="/img/videos/pp.jpg" width=250>
			<ul>
			<p><br>
			Além de promover a saúde, a alimentação saudável<br>
			 também ajuda as pessoas a serem mais felizes.</p></ul>
		</div>
	</div>

</body>

</html>